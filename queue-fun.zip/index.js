﻿var Promise = require('./lib/Promise.js')
exports.Promise = Promise;
exports.Q = require('./lib/Q.js')